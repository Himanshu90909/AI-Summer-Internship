"""
Algorithm 4: KNN -> Similar Patient Identification
Dataset: Heart Disease (reused) - finds nearest-neighbor patients in feature space
and doubles as a classifier for sanity-check accuracy.
"""
import pandas as pd
import numpy as np
import joblib
from sklearn.neighbors import KNeighborsClassifier, NearestNeighbors
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score
from _paths import DATA_DIR, MODELS_DIR
import os

df = pd.read_csv(os.path.join(DATA_DIR, "heart.csv"))
df.columns = [c.strip().lower() for c in df.columns]

FEATURES = ["age", "sex", "cp", "trestbps", "chol", "fbs", "restecg",
            "thalach", "exang", "oldpeak", "slope", "ca", "thal"]
X = df[FEATURES]
y = df["target"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

scaler = StandardScaler()
X_train_s = scaler.fit_transform(X_train)
X_test_s = scaler.transform(X_test)
X_all_s = scaler.transform(X)  # full dataset, scaled, for similarity search

clf = KNeighborsClassifier(n_neighbors=7, weights="distance")
clf.fit(X_train_s, y_train)
acc = accuracy_score(y_test, clf.predict(X_test_s))
print(f"[KNN] Similar Patient Identification -> Accuracy: {acc:.3f}")

# Fit a NearestNeighbors index over the FULL dataset for "find similar patients"
similarity_index = NearestNeighbors(n_neighbors=6, metric="euclidean")
similarity_index.fit(X_all_s)

# Keep a de-identified patient table (index + outcome) to report back neighbors
patient_table = df[FEATURES + ["target"]].copy()
patient_table.insert(0, "patient_id", [f"P{1000+i}" for i in range(len(patient_table))])

joblib.dump({
    "classifier": clf,
    "similarity_index": similarity_index,
    "scaler": scaler,
    "features": FEATURES,
    "patient_table": patient_table,
    "accuracy": round(acc, 4),
    "name": "K-Nearest Neighbors",
    "task": "Similar Patient Identification (Heart Disease)",
}, os.path.join(MODELS_DIR, "knn.joblib"))
print("Saved -> models/knn.joblib")
