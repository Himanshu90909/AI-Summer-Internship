"""
Algorithm 2: Random Forest -> Diagnosis
Dataset: Pima Indians Diabetes (8 clinical features)
"""
import pandas as pd
import joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, roc_auc_score
from _paths import DATA_DIR, MODELS_DIR
import os

df = pd.read_csv(os.path.join(DATA_DIR, "diabetes.csv"))

FEATURES = ["Pregnancies", "Glucose", "BloodPressure", "SkinThickness",
            "Insulin", "BMI", "DiabetesPedigreeFunction", "Age"]
X = df[FEATURES]
y = df["Outcome"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

model = RandomForestClassifier(
    n_estimators=200, max_depth=6, min_samples_leaf=3, random_state=42
)
model.fit(X_train, y_train)

acc = accuracy_score(y_test, model.predict(X_test))
auc = roc_auc_score(y_test, model.predict_proba(X_test)[:, 1])
print(f"[Random Forest] Diagnosis -> Accuracy: {acc:.3f}  AUC: {auc:.3f}")

importances = dict(zip(FEATURES, model.feature_importances_.round(4).tolist()))

joblib.dump({
    "model": model,
    "features": FEATURES,
    "accuracy": round(acc, 4),
    "auc": round(auc, 4),
    "feature_importances": importances,
    "name": "Random Forest",
    "task": "Diagnosis (Diabetes)",
}, os.path.join(MODELS_DIR, "random_forest.joblib"))
print("Saved -> models/random_forest.joblib")
