"""
Algorithm 1: Logistic Regression -> Disease Prediction
Dataset: Heart Disease (UCI Cleveland, 13 clinical features)
"""
import pandas as pd
import joblib
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, roc_auc_score
from _paths import DATA_DIR, MODELS_DIR
import os

df = pd.read_csv(os.path.join(DATA_DIR, "heart.csv"))
df.columns = [c.strip().lower() for c in df.columns]

FEATURES = ["age", "sex", "cp", "trestbps", "chol", "fbs", "restecg",
            "thalach", "exang", "oldpeak", "slope", "ca", "thal"]
X = df[FEATURES]
y = df["target"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

scaler = StandardScaler()
X_train_s = scaler.fit_transform(X_train)
X_test_s = scaler.transform(X_test)

model = LogisticRegression(max_iter=1000, C=1.0)
model.fit(X_train_s, y_train)

acc = accuracy_score(y_test, model.predict(X_test_s))
auc = roc_auc_score(y_test, model.predict_proba(X_test_s)[:, 1])
print(f"[Logistic Regression] Disease Prediction -> Accuracy: {acc:.3f}  AUC: {auc:.3f}")

joblib.dump({
    "model": model,
    "scaler": scaler,
    "features": FEATURES,
    "accuracy": round(acc, 4),
    "auc": round(auc, 4),
    "name": "Logistic Regression",
    "task": "Disease Prediction (Heart Disease)",
}, os.path.join(MODELS_DIR, "logistic_regression.joblib"))
print("Saved -> models/logistic_regression.joblib")
