"""Runs all 8 training scripts in sequence. Usage: python train/train_all.py"""
import subprocess
import sys
import os

SCRIPTS = [
    "train_logistic.py",
    "train_random_forest.py",
    "train_svm.py",
    "train_knn.py",
    "train_kmeans.py",
    "train_pca.py",
    "train_neural_network.py",
    "train_isolation_forest.py",
]

here = os.path.dirname(os.path.abspath(__file__))

for script in SCRIPTS:
    print(f"\n{'='*60}\nRunning {script}\n{'='*60}")
    result = subprocess.run([sys.executable, os.path.join(here, script)])
    if result.returncode != 0:
        print(f"FAILED: {script}")
        sys.exit(1)

print("\nAll 8 models trained successfully. Models saved to ../models/")
