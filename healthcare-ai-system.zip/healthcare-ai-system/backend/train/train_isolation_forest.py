"""
Algorithm 8: Isolation Forest -> Detect Abnormal Health Reports
Dataset: Synthetically generated vitals (heart rate, SpO2, temperature,
respiratory rate, systolic/diastolic BP) with a small fraction of injected
anomalous reports (e.g. dangerously low SpO2, fever + tachycardia combos).
"""
import numpy as np
import pandas as pd
import joblib
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler
from _paths import DATA_DIR, MODELS_DIR
import os

rng = np.random.default_rng(7)
N_NORMAL = 1800
N_ANOMALY = 120

# Normal vitals, physiologically plausible ranges
normal = pd.DataFrame({
    "heart_rate": rng.normal(75, 8, N_NORMAL).clip(50, 100),
    "spo2": rng.normal(97.5, 1.0, N_NORMAL).clip(93, 100),
    "temperature_c": rng.normal(36.8, 0.3, N_NORMAL).clip(35.5, 38),
    "resp_rate": rng.normal(15, 2, N_NORMAL).clip(10, 20),
    "systolic_bp": rng.normal(118, 10, N_NORMAL).clip(90, 140),
    "diastolic_bp": rng.normal(76, 7, N_NORMAL).clip(60, 90),
})
normal["is_anomaly_true"] = 0

# Anomalous vitals: sepsis-like, hypoxia, hypertensive crisis, arrhythmia patterns
anomaly = pd.DataFrame({
    "heart_rate": rng.choice([rng.normal(140, 15, N_ANOMALY).clip(120, 190),
                               rng.normal(38, 6, N_ANOMALY).clip(25, 48)][0], N_ANOMALY),
    "spo2": rng.normal(84, 5, N_ANOMALY).clip(65, 91),
    "temperature_c": rng.normal(39.4, 0.7, N_ANOMALY).clip(38.2, 41.5),
    "resp_rate": rng.normal(28, 4, N_ANOMALY).clip(22, 40),
    "systolic_bp": rng.normal(185, 15, N_ANOMALY).clip(160, 230),
    "diastolic_bp": rng.normal(112, 10, N_ANOMALY).clip(95, 140),
})
anomaly["is_anomaly_true"] = 1

df = pd.concat([normal, anomaly], ignore_index=True).sample(frac=1, random_state=1).reset_index(drop=True)
df.to_csv(os.path.join(DATA_DIR, "vitals_synthetic.csv"), index=False)

FEATURES = ["heart_rate", "spo2", "temperature_c", "resp_rate", "systolic_bp", "diastolic_bp"]
X = df[FEATURES]

scaler = StandardScaler()
X_s = scaler.fit_transform(X)

contamination = N_ANOMALY / (N_NORMAL + N_ANOMALY)
model = IsolationForest(
    n_estimators=200, contamination=contamination, random_state=42
)
model.fit(X_s)

pred = model.predict(X_s)  # -1 = anomaly, 1 = normal
pred_anomaly = (pred == -1).astype(int)

# Evaluate against synthetic ground truth
tp = int(((pred_anomaly == 1) & (df["is_anomaly_true"] == 1)).sum())
fp = int(((pred_anomaly == 1) & (df["is_anomaly_true"] == 0)).sum())
fn = int(((pred_anomaly == 0) & (df["is_anomaly_true"] == 1)).sum())
precision = tp / (tp + fp) if (tp + fp) else 0
recall = tp / (tp + fn) if (tp + fn) else 0
f1 = 2 * precision * recall / (precision + recall) if (precision + recall) else 0

print(f"[Isolation Forest] Abnormal Report Detection -> "
      f"Precision: {precision:.3f}  Recall: {recall:.3f}  F1: {f1:.3f}")

joblib.dump({
    "model": model,
    "scaler": scaler,
    "features": FEATURES,
    "contamination": round(contamination, 4),
    "precision": round(precision, 4),
    "recall": round(recall, 4),
    "f1": round(f1, 4),
    "name": "Isolation Forest",
    "task": "Abnormal Health Report Detection (synthetic vitals)",
}, os.path.join(MODELS_DIR, "isolation_forest.joblib"))
print("Saved -> models/isolation_forest.joblib")
