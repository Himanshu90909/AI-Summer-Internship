"""
Algorithm 5: K-Means -> Patient Grouping / Risk Segmentation
Dataset: Heart Disease (reused) - clusters patients into risk-profile groups
without using the target label (unsupervised).
"""
import pandas as pd
import numpy as np
import joblib
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import silhouette_score
from _paths import DATA_DIR, MODELS_DIR
import os

df = pd.read_csv(os.path.join(DATA_DIR, "heart.csv"))
df.columns = [c.strip().lower() for c in df.columns]

FEATURES = ["age", "trestbps", "chol", "thalach", "oldpeak"]  # continuous vitals
X = df[FEATURES]

scaler = StandardScaler()
X_s = scaler.fit_transform(X)

scores = {}
for k in range(2, 6):
    km = KMeans(n_clusters=k, random_state=42, n_init=10)
    labels = km.fit_predict(X_s)
    score = silhouette_score(X_s, labels)
    scores[k] = score
    print(f"  k={k} silhouette={score:.3f}")

# Prefer k=3 (Low/Medium/High risk groups) for an interpretable demo narrative.
best_k = 3
best_model = KMeans(n_clusters=best_k, random_state=42, n_init=10).fit(X_s)
best_score = scores[best_k]

print(f"[K-Means] Patient Grouping -> k={best_k}  silhouette={best_score:.3f}")

labels = best_model.predict(X_s)
df["cluster"] = labels

# Describe each cluster by its mean vitals -> gives human-readable "risk group" labels
cluster_profiles = df.groupby("cluster")[FEATURES + ["target"]].mean().round(2)
cluster_sizes = df["cluster"].value_counts().sort_index().to_dict()

joblib.dump({
    "model": best_model,
    "scaler": scaler,
    "features": FEATURES,
    "k": best_k,
    "silhouette": round(best_score, 4),
    "cluster_profiles": cluster_profiles,
    "cluster_sizes": cluster_sizes,
    "name": "K-Means Clustering",
    "task": "Patient Grouping (Heart Disease vitals)",
}, os.path.join(MODELS_DIR, "kmeans.joblib"))
print("Saved -> models/kmeans.joblib")
