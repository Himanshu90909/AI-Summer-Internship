"""
Algorithm 6: PCA -> Medical Data Reduction
Dataset: Breast Cancer Wisconsin (30 features) - reduced to 2D for visualization
and to show variance retained at different component counts.
"""
import numpy as np
import joblib
from sklearn.datasets import load_breast_cancer
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from _paths import MODELS_DIR
import os

data = load_breast_cancer()
X, y = data.data, data.target
FEATURES = list(data.feature_names)

scaler = StandardScaler()
X_s = scaler.fit_transform(X)

# Full PCA to inspect explained variance curve
pca_full = PCA().fit(X_s)
explained = pca_full.explained_variance_ratio_
cumulative = np.cumsum(explained)

# 2D projection for plotting
pca_2d = PCA(n_components=2)
X_2d = pca_2d.fit_transform(X_s)

n_for_95 = int(np.argmax(cumulative >= 0.95) + 1)
print(f"[PCA] Medical Data Reduction -> {X.shape[1]} features -> "
      f"{n_for_95} components retain 95% variance")
print(f"  2D projection explains {pca_2d.explained_variance_ratio_.sum()*100:.1f}% variance")

joblib.dump({
    "scaler": scaler,
    "pca_2d": pca_2d,
    "features": FEATURES,
    "explained_variance_ratio": explained.round(4).tolist(),
    "cumulative_variance": cumulative.round(4).tolist(),
    "components_for_95pct": int(n_for_95),
    "projection_2d": X_2d,
    "labels": y,
    "target_names": list(data.target_names),
    "name": "Principal Component Analysis",
    "task": "Medical Data Reduction (Breast Cancer, 30D -> 2D)",
}, os.path.join(MODELS_DIR, "pca.joblib"))
print("Saved -> models/pca.joblib")
