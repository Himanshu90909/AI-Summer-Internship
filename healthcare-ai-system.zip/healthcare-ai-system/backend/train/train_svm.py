"""
Algorithm 3: SVM -> Disease Classification
Dataset: Breast Cancer Wisconsin (sklearn built-in, 30 features)
"""
import joblib
from sklearn.datasets import load_breast_cancer
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, roc_auc_score
from _paths import MODELS_DIR
import os

data = load_breast_cancer()
X, y = data.data, data.target  # 1 = benign, 0 = malignant in sklearn's encoding
FEATURES = list(data.feature_names)

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

scaler = StandardScaler()
X_train_s = scaler.fit_transform(X_train)
X_test_s = scaler.transform(X_test)

model = SVC(kernel="rbf", C=2.0, gamma="scale", probability=True)
model.fit(X_train_s, y_train)

acc = accuracy_score(y_test, model.predict(X_test_s))
auc = roc_auc_score(y_test, model.predict_proba(X_test_s)[:, 1])
print(f"[SVM] Disease Classification -> Accuracy: {acc:.3f}  AUC: {auc:.3f}")

joblib.dump({
    "model": model,
    "scaler": scaler,
    "features": FEATURES,
    "target_names": list(data.target_names),  # ['malignant', 'benign']
    "accuracy": round(acc, 4),
    "auc": round(auc, 4),
    "name": "Support Vector Machine",
    "task": "Disease Classification (Breast Cancer)",
}, os.path.join(MODELS_DIR, "svm.joblib"))
print("Saved -> models/svm.joblib")
