"""
Algorithm 7: Neural Network -> Disease Risk Prediction
Dataset: Synthetically generated multi-factor lifestyle/clinical risk dataset
(age, BMI, blood pressure, cholesterol, smoking, exercise, family history,
glucose) with a realistic nonlinear risk function + noise, so the MLP has to
learn genuine interactions rather than a linear boundary.
"""
import numpy as np
import pandas as pd
import joblib
from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, roc_auc_score
from _paths import DATA_DIR, MODELS_DIR
import os

rng = np.random.default_rng(42)
N = 4000

age = rng.integers(20, 85, N)
bmi = rng.normal(26, 5, N).clip(15, 50)
systolic_bp = rng.normal(125, 18, N).clip(85, 200)
cholesterol = rng.normal(200, 40, N).clip(100, 350)
glucose = rng.normal(100, 25, N).clip(60, 250)
smoking = rng.binomial(1, 0.22, N)
exercise_hours_wk = rng.exponential(2.5, N).clip(0, 15)
family_history = rng.binomial(1, 0.3, N)

# Nonlinear latent risk score -> probability -> binary label
risk_score = (
    0.035 * (age - 20)
    + 0.06 * (bmi - 22).clip(0, None)
    + 0.02 * (systolic_bp - 120).clip(0, None)
    + 0.015 * (cholesterol - 180).clip(0, None)
    + 0.02 * (glucose - 100).clip(0, None)
    + 1.1 * smoking
    - 0.18 * exercise_hours_wk
    + 0.9 * family_history
    + rng.normal(0, 0.45, N)  # noise
)
prob = 1 / (1 + np.exp(-(risk_score - 4.5) / 1.1))
label = rng.binomial(1, prob)

df = pd.DataFrame({
    "age": age, "bmi": bmi.round(1), "systolic_bp": systolic_bp.round(0),
    "cholesterol": cholesterol.round(0), "glucose": glucose.round(0),
    "smoking": smoking, "exercise_hours_wk": exercise_hours_wk.round(1),
    "family_history": family_history, "disease_risk": label,
})
df.to_csv(os.path.join(DATA_DIR, "risk_synthetic.csv"), index=False)

FEATURES = ["age", "bmi", "systolic_bp", "cholesterol", "glucose",
            "smoking", "exercise_hours_wk", "family_history"]
X = df[FEATURES]
y = df["disease_risk"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

scaler = StandardScaler()
X_train_s = scaler.fit_transform(X_train)
X_test_s = scaler.transform(X_test)

model = MLPClassifier(
    hidden_layer_sizes=(32, 16), activation="relu", solver="adam",
    alpha=1e-3, max_iter=500, random_state=42, early_stopping=True,
)
model.fit(X_train_s, y_train)

acc = accuracy_score(y_test, model.predict(X_test_s))
auc = roc_auc_score(y_test, model.predict_proba(X_test_s)[:, 1])
print(f"[Neural Network] Disease Risk Prediction -> Accuracy: {acc:.3f}  AUC: {auc:.3f}")

joblib.dump({
    "model": model,
    "scaler": scaler,
    "features": FEATURES,
    "accuracy": round(acc, 4),
    "auc": round(auc, 4),
    "architecture": "8 -> 32 -> 16 -> 1 (ReLU, Adam, MLPClassifier)",
    "name": "Neural Network (MLP)",
    "task": "Disease Risk Prediction (synthetic lifestyle/clinical data)",
}, os.path.join(MODELS_DIR, "neural_network.joblib"))
print("Saved -> models/neural_network.joblib")
