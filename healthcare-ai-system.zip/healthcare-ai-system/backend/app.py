"""
Healthcare AI System - FastAPI Backend
Serves 8 trained ML models behind a REST API.

Run:
    pip install -r requirements.txt
    python train/train_logistic.py   (repeat for all train_*.py, or use train_all.py)
    uvicorn app:app --reload --port 8000
"""
import os
import joblib
import numpy as np
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import List

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODELS_DIR = os.path.join(BASE_DIR, "models")

app = FastAPI(
    title="Healthcare AI System",
    description="8 ML algorithms for disease prediction, diagnosis, clustering, and anomaly detection",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

_cache = {}


def load(name: str):
    if name not in _cache:
        path = os.path.join(MODELS_DIR, f"{name}.joblib")
        if not os.path.exists(path):
            raise HTTPException(
                status_code=503,
                detail=f"Model '{name}' not trained yet. Run: python train/train_{name}.py",
            )
        _cache[name] = joblib.load(path)
    return _cache[name]


# ---------------------------------------------------------------------------
# 0. Overview - lists all algorithms + their metrics, for the dashboard home
# ---------------------------------------------------------------------------
@app.get("/api/models")
def list_models():
    names = [
        "logistic_regression", "random_forest", "svm", "knn",
        "kmeans", "pca", "neural_network", "isolation_forest",
    ]
    out = []
    for n in names:
        path = os.path.join(MODELS_DIR, f"{n}.joblib")
        if not os.path.exists(path):
            out.append({"id": n, "trained": False})
            continue
        m = load(n)
        entry = {"id": n, "trained": True, "name": m.get("name"), "task": m.get("task")}
        for key in ("accuracy", "auc", "silhouette", "precision", "recall", "f1", "k"):
            if key in m:
                entry[key] = m[key]
        out.append(entry)
    return {"algorithms": out}


# ---------------------------------------------------------------------------
# 1. Logistic Regression -> Disease Prediction (Heart Disease)
# ---------------------------------------------------------------------------
class HeartInput(BaseModel):
    age: float
    sex: int = Field(description="1=male, 0=female")
    cp: int = Field(description="chest pain type 0-3")
    trestbps: float = Field(description="resting blood pressure")
    chol: float = Field(description="serum cholesterol mg/dl")
    fbs: int = Field(description="fasting blood sugar > 120 mg/dl, 1=true")
    restecg: int
    thalach: float = Field(description="max heart rate achieved")
    exang: int = Field(description="exercise induced angina, 1=yes")
    oldpeak: float
    slope: int
    ca: int = Field(description="number of major vessels colored")
    thal: int


@app.post("/api/logistic-regression/predict")
def predict_logistic(data: HeartInput):
    m = load("logistic_regression")
    x = np.array([[getattr(data, f) for f in m["features"]]])
    x_s = m["scaler"].transform(x)
    prob = m["model"].predict_proba(x_s)[0, 1]
    pred = int(prob >= 0.5)
    return {
        "prediction": pred,
        "label": "Disease Likely" if pred else "No Disease Indicated",
        "probability": round(float(prob), 4),
        "model_accuracy": m["accuracy"],
        "model_auc": m["auc"],
    }


# ---------------------------------------------------------------------------
# 2. Random Forest -> Diagnosis (Diabetes)
# ---------------------------------------------------------------------------
class DiabetesInput(BaseModel):
    Pregnancies: float
    Glucose: float
    BloodPressure: float
    SkinThickness: float
    Insulin: float
    BMI: float
    DiabetesPedigreeFunction: float
    Age: float


@app.post("/api/random-forest/predict")
def predict_random_forest(data: DiabetesInput):
    m = load("random_forest")
    x = np.array([[getattr(data, f) for f in m["features"]]])
    prob = m["model"].predict_proba(x)[0, 1]
    pred = int(prob >= 0.5)
    return {
        "prediction": pred,
        "label": "Diabetic" if pred else "Non-Diabetic",
        "probability": round(float(prob), 4),
        "model_accuracy": m["accuracy"],
        "model_auc": m["auc"],
        "feature_importances": m["feature_importances"],
    }


# ---------------------------------------------------------------------------
# 3. SVM -> Disease Classification (Breast Cancer)
# ---------------------------------------------------------------------------
class TumorInput(BaseModel):
    features: List[float] = Field(description="30 numeric features from a breast mass FNA")


@app.post("/api/svm/predict")
def predict_svm(data: TumorInput):
    m = load("svm")
    if len(data.features) != len(m["features"]):
        raise HTTPException(400, f"Expected {len(m['features'])} features, got {len(data.features)}")
    x = np.array([data.features])
    x_s = m["scaler"].transform(x)
    prob = m["model"].predict_proba(x_s)[0]
    pred = int(np.argmax(prob))
    return {
        "prediction": pred,
        "label": m["target_names"][pred],
        "probability_malignant": round(float(prob[0]), 4),
        "probability_benign": round(float(prob[1]), 4),
        "model_accuracy": m["accuracy"],
        "model_auc": m["auc"],
    }


@app.get("/api/svm/sample")
def svm_sample():
    """Returns a random real sample from the breast cancer dataset for demo purposes."""
    from sklearn.datasets import load_breast_cancer
    data = load_breast_cancer()
    idx = int(np.random.randint(0, len(data.data)))
    return {
        "features": data.data[idx].tolist(),
        "true_label": data.target_names[data.target[idx]],
        "feature_names": list(data.feature_names),
    }


# ---------------------------------------------------------------------------
# 4. KNN -> Similar Patient Identification (Heart Disease)
# ---------------------------------------------------------------------------
@app.post("/api/knn/similar-patients")
def knn_similar(data: HeartInput):
    m = load("knn")
    x = np.array([[getattr(data, f) for f in m["features"]]])
    x_s = m["scaler"].transform(x)

    pred = int(m["classifier"].predict(x_s)[0])
    dist, idx = m["similarity_index"].kneighbors(x_s, n_neighbors=6)

    table = m["patient_table"]
    neighbors = []
    for d, i in zip(dist[0], idx[0]):
        row = table.iloc[i]
        neighbors.append({
            "patient_id": row["patient_id"],
            "distance": round(float(d), 3),
            "age": int(row["age"]),
            "outcome": "Disease" if row["target"] == 1 else "No Disease",
        })

    return {
        "predicted_diagnosis": "Disease Likely" if pred else "No Disease Indicated",
        "model_accuracy": m["accuracy"],
        "similar_patients": neighbors,
    }


# ---------------------------------------------------------------------------
# 5. K-Means -> Patient Grouping
# ---------------------------------------------------------------------------
class VitalsGroupInput(BaseModel):
    age: float
    trestbps: float = Field(description="resting blood pressure")
    chol: float
    thalach: float = Field(description="max heart rate")
    oldpeak: float


@app.post("/api/kmeans/group")
def kmeans_group(data: VitalsGroupInput):
    m = load("kmeans")
    x = np.array([[getattr(data, f) for f in m["features"]]])
    x_s = m["scaler"].transform(x)
    cluster = int(m["model"].predict(x_s)[0])
    profile = m["cluster_profiles"].loc[cluster].to_dict()
    return {
        "cluster": cluster,
        "cluster_size": m["cluster_sizes"].get(cluster),
        "cluster_profile_means": {k: round(v, 2) for k, v in profile.items()},
        "silhouette_score": m["silhouette"],
    }


@app.get("/api/kmeans/clusters")
def kmeans_clusters():
    m = load("kmeans")
    profiles = m["cluster_profiles"].reset_index().to_dict(orient="records")
    return {
        "k": m["k"],
        "silhouette_score": m["silhouette"],
        "cluster_sizes": m["cluster_sizes"],
        "cluster_profiles": profiles,
    }


# ---------------------------------------------------------------------------
# 6. PCA -> Medical Data Reduction
# ---------------------------------------------------------------------------
@app.get("/api/pca/projection")
def pca_projection():
    m = load("pca")
    points = [
        {"x": round(float(p[0]), 3), "y": round(float(p[1]), 3), "label": int(l)}
        for p, l in zip(m["projection_2d"], m["labels"])
    ]
    return {
        "points": points,
        "target_names": m["target_names"],
        "explained_variance_ratio_2d": [round(v, 4) for v in m["pca_2d"].explained_variance_ratio_],
        "cumulative_variance": m["cumulative_variance"],
        "components_for_95pct": m["components_for_95pct"],
        "original_dimensions": len(m["features"]),
    }


# ---------------------------------------------------------------------------
# 7. Neural Network -> Disease Risk Prediction
# ---------------------------------------------------------------------------
class RiskInput(BaseModel):
    age: float
    bmi: float
    systolic_bp: float
    cholesterol: float
    glucose: float
    smoking: int = Field(description="1=smoker, 0=non-smoker")
    exercise_hours_wk: float
    family_history: int = Field(description="1=yes, 0=no")


@app.post("/api/neural-network/predict")
def predict_nn(data: RiskInput):
    m = load("neural_network")
    x = np.array([[getattr(data, f) for f in m["features"]]])
    x_s = m["scaler"].transform(x)
    prob = m["model"].predict_proba(x_s)[0, 1]
    pred = int(prob >= 0.5)
    return {
        "prediction": pred,
        "label": "Elevated Risk" if pred else "Low Risk",
        "probability": round(float(prob), 4),
        "model_accuracy": m["accuracy"],
        "model_auc": m["auc"],
        "architecture": m["architecture"],
    }


# ---------------------------------------------------------------------------
# 8. Isolation Forest -> Detect Abnormal Health Reports
# ---------------------------------------------------------------------------
class VitalsAnomalyInput(BaseModel):
    heart_rate: float
    spo2: float
    temperature_c: float
    resp_rate: float
    systolic_bp: float
    diastolic_bp: float


@app.post("/api/isolation-forest/detect")
def detect_anomaly(data: VitalsAnomalyInput):
    m = load("isolation_forest")
    x = np.array([[getattr(data, f) for f in m["features"]]])
    x_s = m["scaler"].transform(x)
    raw_pred = m["model"].predict(x_s)[0]  # -1 anomaly, 1 normal
    score = m["model"].decision_function(x_s)[0]  # higher = more normal
    is_anomaly = bool(raw_pred == -1)
    return {
        "is_anomaly": is_anomaly,
        "label": "Abnormal Report - Review Needed" if is_anomaly else "Normal Report",
        "anomaly_score": round(float(-score), 4),  # flip sign: higher = more anomalous
        "model_precision": m["precision"],
        "model_recall": m["recall"],
        "model_f1": m["f1"],
    }


@app.get("/")
def root():
    return {
        "message": "Healthcare AI System API",
        "docs": "/docs",
        "algorithms": "/api/models",
    }
