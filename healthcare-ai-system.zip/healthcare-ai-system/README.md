# Healthcare AI System

A full-stack machine learning system combining **8 algorithms** into one clinical intelligence console — a FastAPI backend serving real trained models, and a single-file dashboard frontend.

## Algorithms & Datasets

| # | Algorithm | Task | Dataset |
|---|-----------|------|---------|
| 01 | Logistic Regression | Disease Prediction | Heart Disease (UCI Cleveland, 13 features) |
| 02 | Random Forest | Diagnosis | Pima Indians Diabetes (8 features) |
| 03 | SVM (RBF kernel) | Disease Classification | Breast Cancer Wisconsin (30 features) |
| 04 | KNN | Similar Patient Identification | Heart Disease (reused) |
| 05 | K-Means | Patient Grouping | Heart Disease vitals (unsupervised) |
| 06 | PCA | Medical Data Reduction | Breast Cancer, 30D → 2D |
| 07 | Neural Network (MLP) | Disease Risk Prediction | Synthetic lifestyle/clinical dataset (4,000 records) |
| 08 | Isolation Forest | Abnormal Report Detection | Synthetic vitals w/ injected anomalies |

## Project Structure

```
healthcare-ai-system/
├── backend/
│   ├── app.py                  # FastAPI app — all 8 endpoints
│   ├── requirements.txt
│   ├── data/                   # heart.csv, diabetes.csv + generated synthetic sets
│   ├── models/                 # trained .joblib files (created after training)
│   └── train/
│       ├── train_logistic.py
│       ├── train_random_forest.py
│       ├── train_svm.py
│       ├── train_knn.py
│       ├── train_kmeans.py
│       ├── train_pca.py
│       ├── train_neural_network.py
│       ├── train_isolation_forest.py
│       └── train_all.py        # runs all 8 in sequence
└── frontend/
    └── index.html              # single-file dashboard, calls the API
```

## Setup

```bash
cd healthcare-ai-system/backend
pip install -r requirements.txt

# Train all 8 models (takes under a minute)
python train/train_all.py

# Start the API
uvicorn app:app --reload --port 8000
```

Then open `frontend/index.html` directly in your browser (or serve it with
`python -m http.server` from the `frontend/` folder). It talks to the API at
`http://127.0.0.1:8000` — CORS is already open for local development.

API docs (interactive Swagger UI) are auto-generated at `http://127.0.0.1:8000/docs`.

## API Endpoints

- `GET  /api/models` — overview of all 8 models + their metrics
- `POST /api/logistic-regression/predict`
- `POST /api/random-forest/predict`
- `POST /api/svm/predict` · `GET /api/svm/sample`
- `POST /api/knn/similar-patients`
- `POST /api/kmeans/group` · `GET /api/kmeans/clusters`
- `GET  /api/pca/projection`
- `POST /api/neural-network/predict`
- `POST /api/isolation-forest/detect`

## Model Performance (on held-out test sets)

- **Logistic Regression**: 80.3% accuracy, 0.869 AUC
- **Random Forest**: 76.0% accuracy, 0.813 AUC
- **SVM**: 98.3% accuracy, 0.997 AUC
- **KNN**: 82.0% accuracy
- **K-Means**: k=3, silhouette 0.227
- **PCA**: 10 of 30 components retain 95% variance; 2D projection retains 63.2%
- **Neural Network**: 82.4% accuracy, 0.735 AUC
- **Isolation Forest**: precision 1.00, recall 1.00, F1 1.00 (on synthetic ground truth)

## Notes for extending this project

- The Neural Network currently uses `sklearn.neural_network.MLPClassifier`. Swapping
  in TensorFlow/Keras or PyTorch is a drop-in replacement in `train_neural_network.py`
  and would be a good next step if you want that framework experience on your resume.
- All datasets are either real (heart disease, diabetes, breast cancer) or clearly
  documented synthetic generators (`train_neural_network.py`, `train_isolation_forest.py`)
  — useful to mention in a project writeup or viva.
- To deploy: containerize `backend/` with Docker, host on Cloud Run (matches your
  existing GCP stack), and serve `frontend/index.html` from any static host — just
  update `API_BASE` in the `<script>` tag.
